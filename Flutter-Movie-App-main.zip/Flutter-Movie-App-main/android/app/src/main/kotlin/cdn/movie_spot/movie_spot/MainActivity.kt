package cdn.movie_spot.movie_spot

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
